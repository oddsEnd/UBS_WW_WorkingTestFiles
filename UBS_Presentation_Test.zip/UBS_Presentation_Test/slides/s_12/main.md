``sequence
Alice->Bob: Hello Bob
Bob-->Alice: Where am I?
``