### Asset accumulation

<br>

1. Retirement is a debt that you owe yourself
2. During accumulation: goal is to maximize wealth a point of retirement 
3. Long time horizons hlep, but YOLO
4. Think like a burglar
