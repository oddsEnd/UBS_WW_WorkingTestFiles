http://bl.ocks.org/atmccann/8966400

#### Data file

Name:   data.csv
Source: Federal Reserve Bank

Percent change from 1 year ago. In %.

data1 = Civilian Unemployment Rate (UNRATENSA), https://fred.stlouisfed.org/series/UNRATENSA
data2 = Russell 1000 Total Market Index (RU1000TR), https://fred.stlouisfed.org/series/RU1000TR#0
