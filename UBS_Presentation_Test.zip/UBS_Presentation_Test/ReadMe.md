# Presentation Instructions

- Use the _Chrome_ web browser
- Press `F11` for full screen
- Go to [http://localhost:8000/](http://localhost:8000/)

## Opening the presentation

To load all of the content in the slides locally you need to run a server in the local folder. This can be done quickly and efficiently with Python(TM).

> Python can be downloaded at [https://www.python.org](https://www.python.org/)

A step by step guide for setting up a **Python**(TM) simple server are available [here](https://developer.mozilla.org/en-US/docs/Learn/Common_questions/set_up_a_local_testing_server#Running_a_simple_local_HTTP_server).

#### Running a local HTTP server with Python(TM)

From the Windows(R) command prompt, navigate to the folder with the index.html file and type:

**_Python 2.x_** `python -m SimpleHTTPServer`

**_Python 3.x_** `python -m http.server`

> Example
>
> ![Run http server with python 3.x](images/cmd-python-3x-example.png)
