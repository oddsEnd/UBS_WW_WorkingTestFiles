// https://d3js.org v5.9.2 Copyright 2019 Mike Bostock
!(function(t, n) {
  "object" == typeof exports && "undefined" != typeof module
    ? n(exports)
    : "function" == typeof define && define.amd
    ? define(["exports"], n)
    : n((t.l4 = t.l4 || {}));
})(this, function(t) {
  "use strict";

  t.getWW = getWW;
  t.getValues = getValues;
  t.wwToElla = getValues; // convert
  t.getVarFullNames = getVarFullNames;
  t.getColors = getColors;
  t.sumArrays = sumArrays;

  // let l4_sumArrays = (r, a) => r.map((b, i) => a[i] + b);

  function sumArrays(arrArr) {
    const _sums = (r, a) => r.map((b, i) => a[i] + b);
    return arrArr.reduce(_sums);
  }

  function getVarFullNames(Names) {
    if (typeof Names == "string") return variable_fullnames()[Names];

    if (typeof Names == "object") {
      const objKey = variable_fullnames();

      var varNames = Array.isArray(Names) ? Names : Object.keys(Names);
      var fullnames = {};

      varNames.reduce(function(d, varName) {
        return (fullnames[varName] = objKey[varName]);
      }, fullnames);

      return Array.isArray(Names) ? Object.values(fullnames) : fullnames;
    }
  }

  function getWW(data) {
    const inputs = getByFilter(data, "inputs");
    const outputs = getByFilter(data, "outputs");
    const flows = data[2];

    if (!inputs || !outputs)
      throw new Error("Missing inputs or outputs object.");

    // make totalSpend positive
    flows.totalSpend = flows.totalSpend.map(cf => Math.abs(cf));

    return {
      years: outputs.rows,
      yearFirst: outputs.rows[0],
      yearFinal: outputs.rows[outputs.rows.length - 1],
      columns: outputs.columns, // depreciate to trials (see next line)
      trials: outputs.columns, // rename to trials?
      tgtLiq: outputs.tgtLiqValues,
      tgtLng: outputs.tgtLngValues,
      current: outputs.values,
      targeted: outputs.valuesTgtPos,
      pos: {
        current: inputs.current_PoS,
        targeted: inputs.PoSTarget
      },
      liqYrs: inputs.liq_yr,
      ...flows,
      expenseGap: inputs.exp_gap
    };
  }

  function getValues(wwData, ptile, from = "current") {
    let V = ptile ? ptile - 1 : 85 - 1;
    let arr = [];

    for (let i = 0; i < wwData.years.length; i++) {
      let obj = {
        year: wwData.years[i],
        liq: wwData[from].liq[i][V],
        lng: wwData[from].lng[i][V],
        leg: wwData[from].leg[i][V],
        shortLiq: 0,
        shortLng: 0,
        tgtLiq: wwData.tgtLiq[i],
        tgtLng: wwData.tgtLng[i],
        totalSave: wwData.totalSave[i],
        totalIncome: wwData.totalIncome[i],
        totalSpend: wwData.totalSpend[i],
        incomeSaved: wwData.incomeSaved[i],
        expenseGap: wwData.expenseGap[i]
      };

      // Total value of Liquidity + Longevity + Legacy
      obj.pfoTotal = obj.liq + obj.lng + obj.leg;

      // Get short fall of Liquidity, Longevity
      if (obj.liq < obj.tgtLiq) obj.shortLiq = obj.tgtLiq - obj.liq;
      if (obj.lng < obj.tgtLng) obj.shortLng = obj.tgtLng - obj.lng;

      arr.push(obj);
    }

    return arr;
  }

  function getColors(k) {
    if (!k) return colors_ubs_primary();

    if (typeof k == "string") {
      switch (k.toLocaleLowerCase()) {
        case "primary":
          return colors_ubs_primary();

        case "3ls":
        case "3l":
        case "ls":
        case "lll":
          return colors_ubs_ella();
      }
    }
  }

  // k
  function colors_ubs_primary() {
    return {
      chocolate: "#585148",
      caramel: "#D7C2AA",
      terracotta: "#B7735A",
      honey: "#E8C880",
      carbon: "#646464",
      chestnut: "#9A3D37",
      straw: "#F1E4BA",
      smoke: "#919191",
      cinnamon: "#D4AD9C",
      glacier: "#BFD6EB",
      pine: "#3C8287",
      mouse: "#BBB3AC",
      plum: "#5a6f89",
      atlantic: "#4D92B4",
      clay: "#887A6D",
      curry: "#DBAA35",
      olive: "#788D41",
      lilac: "#879ab5",
      stone: "#bebebe",
      fern: "#B4B77B",
      sand: "#B89D83",
      lavender: "#BDC6D4",
      ginger: "#FDDECD",
      sage: "#C6D9CE",
      lake: "#92B8D6",
      lemongrass: "#DEDFB3",
      mint: "#94B9B6"
    };
  }

  function colors_ubs_ella() {
    return {
      liq: "#C4DAE5",
      shortLiq: "#E9F1F5", //"#E9F1F5",
      lng: "#BFB6AC",
      shortLng: "#EDEBE8",
      leg: "#EDE2CE",
      tgtLiq: "green",
      tgtLng: "orange",
      totalSave: "brown",
      totalIncome: "blue",
      totalSpend: "tomato",
      incomeSaved: "yellow",
      liquidity: "#C4DAE5",
      longevity: "#BFB6AC",
      legacy: "#EDE2CE",
      liquidity_shortfall: "#E9F1F5",
      longevity_shortfall: "#EDEBE8"
    };
  }

  function variable_fullnames() {
    return {
      liq: "Liquidity",
      shortLiq: "Liquidity underfund",
      lng: "Longevity",
      shortLng: "Longevity underfund",
      leg: "Legacy",
      tgtLiq: "Liquidity target",
      tgtLng: "Longevity target",
      totalSave: "Save",
      totalIncome: "Income",
      totalSpend: "Spend",
      incomeSaved: "Income saved",
      liquidity: "Liquidity",
      longevity: "Longevity",
      legacy: "Legacy",
      liquidity_shortfall: "Liquidity underfund",
      longevity_shortfall: "Longevity underfund"
    };
  }

  // Filter wealth way data to find group type
  function getByFilter(data, group) {
    const _data = data.filter(d => d.group === group);
    return _data.length > 1 ? _data : _data[0];
  }

  // Perform a numeric sort on an array
  function sortNumber(a, b) {
    return a - b;
  }
});
