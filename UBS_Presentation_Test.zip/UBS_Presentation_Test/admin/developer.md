# UBS

## Design resources

- [https://ubs.frontify.com/](https://ubs.frontify.com/)

## Disclosures

**Liquidity. Longevity. Legacy.**

> Timeframes may vary. Strategies are subject to individual client goals, objectives and suitability. This approach is not a promise or guarantee that wealth, or financial results, can or will be achieved.

# reveal.js

### Plug-ins to consider

https://github.com/hakimel/reveal.js/wiki/Plugins,-Tools-and-Hardware

- Look for `diagram-plugin`
